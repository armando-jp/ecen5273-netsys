#ifndef INC_ENCRYPTION_
#define INC_ENCRYPTION_

void encrypt_decrypt(char *input, int input_length, char *key, int key_length);

#endif /*INC_ENCRYPTION_*/
